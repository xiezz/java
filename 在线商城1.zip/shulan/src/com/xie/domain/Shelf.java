package com.xie.domain;

import java.util.HashSet;
import java.util.Set;

/**
 * Shelf entity. @author MyEclipse Persistence Tools
 */

public class Shelf implements java.io.Serializable {

	// Fields

	private Integer sid;
	private String place;
	private String type;
	private Set losses = new HashSet(0);
	private Set products = new HashSet(0);

	// Constructors

	/** default constructor */
	public Shelf() {
	}

	@Override
	public String toString() {
		return "Shelf [sid=" + sid + ", place=" + place + ", type=" + type
				+ ", losses=" + losses + ", products=" + products + "]";
	}

	/** full constructor */
	public Shelf(String place, String type, Set losses, Set products) {
		this.place = place;
		this.type = type;
		this.losses = losses;
		this.products = products;
	}

	// Property accessors

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public String getPlace() {
		return this.place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Set getLosses() {
		return this.losses;
	}

	public void setLosses(Set losses) {
		this.losses = losses;
	}

	public Set getProducts() {
		return this.products;
	}

	public void setProducts(Set products) {
		this.products = products;
	}

}