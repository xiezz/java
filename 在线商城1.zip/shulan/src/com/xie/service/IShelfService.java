package com.xie.service;

import java.util.List;

import com.xie.domain.Shelf;

public interface IShelfService {
	public void save(Shelf r);
	public void delete(Integer rid);
	public void update(Shelf r);
	public List<Shelf> find();
	public Shelf find(Integer rid);
}
