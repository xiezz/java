package com.xie.dao;

import java.util.List;

import com.xie.domain.Loss;

public interface ILossDao {
	public void save(Loss r);
	public void delete(Integer rid);
	public void update(Loss r);
	public List<Loss> find();
	public Loss find(Integer rid);
}
