package com.xie.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.xie.dao.IProductDao;
import com.xie.domain.Product;

@Repository
public class ProductDaoImpl implements IProductDao {

	@Autowired
	private SessionFactory sf;
	
	private Session getSession(){
		return sf.getCurrentSession();
	}
	public void save(Product r) {
		getSession().save(r);
	}

	public void delete(Integer rid) {
		Product r = (Product) getSession().get(Product.class, rid);
		getSession().delete(r);
	}

	public void update(Product r) {
		getSession().update(r);
	}

	public List<Product> find() {
		return getSession().createQuery("FROM Product").list();
	}

	public Product find(Integer rid) {
		Product r = (Product) getSession().get(Product.class, rid);
		return r;
	}

}
