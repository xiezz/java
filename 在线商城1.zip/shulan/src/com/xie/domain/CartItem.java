package com.xie.domain;

import java.math.BigDecimal;


public class CartItem {
	public CartItem(Integer id, String name, Double price, Integer num,
			Integer leftNum) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.num = num;
		this.leftNum = leftNum;
	}
	@Override
	public String toString() {
		return "CartItem [id=" + id + ", name=" + name + ", price=" + price
				+ ", num=" + num + ", leftNum=" + leftNum + "]";
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Integer getNum() {
		return num;
	}
	public void setNum(Integer num) {
		this.num = num;
	}
	public Integer getLeftNum() {
		return leftNum;
	}
	public void setLeftNum(Integer leftNum) {
		this.leftNum = leftNum;
	}
	private Integer id;
	private String name;
	private Double price;
	private Integer num;
	private Integer leftNum;
	public CartItem(){}
	
	
	
}
