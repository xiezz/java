package com.xie.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.xie.dao.IUserDao;
import com.xie.domain.User;

@Repository
public class UserDaoImpl implements IUserDao {

	@Autowired
	private SessionFactory sf;
	
	private Session getSession(){
		return sf.getCurrentSession();
	}
	public void save(User r) {
		getSession().save(r);
	}

	public void delete(Integer rid) {
		User r = (User) getSession().get(User.class, rid);
		getSession().delete(r);
	}

	public void update(User r) {
		getSession().update(r);
	}

	public List<User> find() {
		return getSession().createQuery("FROM User").list();
	}

	public User find(Integer rid) {
		User r = (User) getSession().get(User.class, rid);
		return r;
	}

}
