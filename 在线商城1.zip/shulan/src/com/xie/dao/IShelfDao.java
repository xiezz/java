package com.xie.dao;

import java.util.List;

import com.xie.domain.Shelf;

public interface IShelfDao {
	public void save(Shelf r);
	public void delete(Integer rid);
	public void update(Shelf r);
	public List<Shelf> find();
	public Shelf find(Integer rid);
}
