package com.xie.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xie.dao.IProductDao;
import com.xie.domain.Product;
import com.xie.service.IProductService;

@Service
@Transactional
public class ProductSeriveImpl implements IProductService{
	
	@Autowired
	private IProductDao dao;
	public void save(Product r) {
		dao.save(r);
	}

	public void delete(Integer rid) {
		dao.delete(rid);
	}

	public void update(Product r) {
		dao.update(r);
	}

	public List<Product> find() {
		return dao.find();
	}

	public Product find(Integer rid) {
		return dao.find(rid);
	}

}
