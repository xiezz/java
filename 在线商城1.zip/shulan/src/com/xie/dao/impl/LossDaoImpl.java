package com.xie.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.xie.dao.ILossDao;
import com.xie.domain.Product;
import com.xie.domain.Loss;

@Repository
public class LossDaoImpl implements ILossDao {
	
	@Autowired
	private SessionFactory sf;
	
	private Session getSession(){
		return sf.openSession();
	}

	public void save(Loss Loss) {
		getSession().save(Loss);
	}

	public void delete(Integer rid) {
		Loss r = (Loss) getSession().get(Loss.class, rid);
		getSession().delete(r);
	}

	public void update(Loss Loss) {
		getSession().update(Loss);
	}

	public List<Loss> find() {
		Query q = getSession().createQuery("FROM Loss");
		List<Loss> list = q.list();
		return list;
	}

	public Loss find(Integer id) {
		Query q = getSession().createQuery("FROM Loss WHERE  id = ?");
		q.setParameter(0, id);
		Loss Loss = (Loss) q.uniqueResult();
		return Loss;
	}

}
