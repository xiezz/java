package com.xie.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.xie.dao.IShelfDao;
import com.xie.domain.Shelf;

@Repository
public class ShelfDaoImpl implements IShelfDao {

	@Autowired
	private SessionFactory sf;
	
	private Session getSession(){
		return sf.getCurrentSession();
	}
	public void save(Shelf r) {
		getSession().save(r);
	}

	public void delete(Integer rid) {
		Shelf r = (Shelf) getSession().get(Shelf.class, rid);
		getSession().delete(r);
	}

	public void update(Shelf r) {
		getSession().update(r);
	}

	public List<Shelf> find() {
		return getSession().createQuery("FROM Shelf").list();
	}

	public Shelf find(Integer rid) {
		Shelf r = (Shelf) getSession().get(Shelf.class, rid);
		return r;
	}

}
