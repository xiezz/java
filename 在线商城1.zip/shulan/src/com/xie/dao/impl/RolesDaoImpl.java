package com.xie.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.xie.dao.IRolesDao;
import com.xie.domain.Roles;

@Repository
public class RolesDaoImpl implements IRolesDao {
	
	@Autowired
	private SessionFactory sf;
	
	private Session getSession(){
		return sf.openSession();
	}

	public void save(Roles Roles) {
		getSession().save(Roles);
	}

	public void delete(Integer id) {
		Roles Roles = (Roles) getSession().get(Roles.class,id);
		getSession().delete(Roles);

	}

	public void update(Roles Roles) {
		getSession().update(Roles);
	}

	public List<Roles> find() {
		Query q = getSession().createQuery("FROM Roles");
		List<Roles> list = q.list();
		return list;
	}

	public Roles find(Integer id) {
		Query q = getSession().createQuery("FROM Roles WHERE  id = ?");
		q.setParameter(0, id);
		Roles Roles = (Roles) q.uniqueResult();
		return Roles;
	}

}
