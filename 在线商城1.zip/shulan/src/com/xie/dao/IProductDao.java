package com.xie.dao;

import java.util.List;

import com.xie.domain.Product;

public interface IProductDao {
	public void save(Product r);
	public void delete(Integer rid);
	public void update(Product r);
	public List<Product> find();
	public Product find(Integer rid);
}
