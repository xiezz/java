package com.xie.domain;

import java.util.HashSet;
import java.util.Set;

/**
 * Product entity. @author MyEclipse Persistence Tools
 */

public class Product implements java.io.Serializable {

	// Fields

	private Integer pid;
	private String productName;
	private Double salePrice;
	private String supplier;
	private String brand;
	private Double cutoff;
	private Double costPrice;
	private Integer leftNum;
	private Integer saleNum;
	private Set losses = new HashSet(0);
	private Set shelfs = new HashSet(0);

	// Constructors

	/** default constructor */
	public Product() {
	}

	/** full constructor */
	public Product(String productName, Double salePrice, String supplier,
			String brand, Double cutoff, Double costPrice, Integer leftNum,
			Integer saleNum, Set losses, Set shelfs) {
		this.productName = productName;
		this.salePrice = salePrice;
		this.supplier = supplier;
		this.brand = brand;
		this.cutoff = cutoff;
		this.costPrice = costPrice;
		this.leftNum = leftNum;
		this.saleNum = saleNum;
		this.losses = losses;
		this.shelfs = shelfs;
	}

	// Property accessors

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getProductName() {
		return this.productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getSalePrice() {
		return this.salePrice;
	}

	public void setSalePrice(Double salePrice) {
		this.salePrice = salePrice;
	}

	public String getSupplier() {
		return this.supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public String getBrand() {
		return this.brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public Double getCutoff() {
		return this.cutoff;
	}

	public void setCutoff(Double cutoff) {
		this.cutoff = cutoff;
	}

	public Double getCostPrice() {
		return this.costPrice;
	}

	public void setCostPrice(Double costPrice) {
		this.costPrice = costPrice;
	}

	public Integer getLeftNum() {
		return this.leftNum;
	}

	public void setLeftNum(Integer leftNum) {
		this.leftNum = leftNum;
	}

	public Integer getSaleNum() {
		return this.saleNum;
	}

	public void setSaleNum(Integer saleNum) {
		this.saleNum = saleNum;
	}

	public Set getLosses() {
		return this.losses;
	}

	public void setLosses(Set losses) {
		this.losses = losses;
	}

	public Set getShelfs() {
		return this.shelfs;
	}

	public void setShelfs(Set shelfs) {
		this.shelfs = shelfs;
	}

}