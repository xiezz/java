package com.xie.dao;

import java.util.List;
import com.xie.domain.Roles;

public interface IRolesDao {
	public void save(Roles Roles);
	public void delete(Integer id);
	public void update(Roles Roles);
	public List<Roles> find();	
	public Roles find(Integer id );
}	
