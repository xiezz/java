package com.xie.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xie.domain.User;
import com.xie.service.IUserService;

@Controller
@RequestMapping("/login")
public class checkLoginAction {
	@Autowired
	private IUserService service;
	@RequestMapping("/check")
	protected String check(String username, String password, HttpSession session,HttpServletRequest req)
			throws ServletException, IOException {
		String username1 = new String(username.getBytes("ISO-8859-1"),"utf-8");
		List<User> list = service.find();
		for (User user : list) {
			if (user.getUsername().equals(username1)&&user.getPassword().equals(password)) {
				session.setAttribute("username", username1);
				return "views/product/welcome";
			}
		}
				return "views/product/fail";
		
	}
}
