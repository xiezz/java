package com.xie.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xie.domain.Product;
import com.xie.service.IProductService;

@Controller
@RequestMapping("/productadd")
public class addAction {
	@Autowired
	private IProductService service;
	
	@RequestMapping("/add")
	public String  save( HttpServletRequest req, HttpServletResponse resp, HttpSession session) throws ServletException, IOException{
		List<Product> list = service.find();
		for (Product product : list) {
			String newNum = req.getParameter(String.valueOf(product.getPid()));
			product.setLeftNum(Integer.valueOf(newNum));
			service.update(product);
		}
		list = service.find();
		session.setAttribute("products", list);
		return "views/product/add";
	}
}		
