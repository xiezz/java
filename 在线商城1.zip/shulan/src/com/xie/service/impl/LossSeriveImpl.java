package com.xie.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xie.dao.ILossDao;
import com.xie.domain.Loss;
import com.xie.service.ILossService;

@Service
@Transactional
public class LossSeriveImpl implements ILossService{
	
	@Autowired
	private ILossDao dao;
	public void save(Loss r) {
		dao.save(r);
	}

	public void delete(Integer rid) {
		dao.delete(rid);
	}

	public void update(Loss r) {
		dao.update(r);
	}

	public List<Loss> find() {
		return dao.find();
	}

	public Loss find(Integer rid) {
		return dao.find(rid);
	}

}
