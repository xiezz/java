package com.xie.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xie.dao.IRolesDao;
import com.xie.domain.Roles;
import com.xie.service.IRolesService;

@Service
@Transactional
public class RolesSeriveImpl implements IRolesService{
	
	@Autowired
	private IRolesDao dao;
	public void save(Roles r) {
		dao.save(r);
	}

	public void delete(Integer rid) {
		dao.delete(rid);
	}

	public void update(Roles r) {
		dao.update(r);
	}

	public List<Roles> find() {
		return dao.find();
	}

	public Roles find(Integer rid) {
		return dao.find(rid);
	}

}
