package com.xie.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xie.dao.IUserDao;
import com.xie.domain.User;
import com.xie.service.IUserService;

@Service
@Transactional
public class UserSeriveImpl implements IUserService{
	
	@Autowired
	private IUserDao dao;
	public void save(User r) {
		dao.save(r);
	}

	public void delete(Integer rid) {
		dao.delete(rid);
	}

	public void update(User r) {
		dao.update(r);
	}

	public List<User> find() {
		return dao.find();
	}

	public User find(Integer rid) {
		return dao.find(rid);
	}

}
