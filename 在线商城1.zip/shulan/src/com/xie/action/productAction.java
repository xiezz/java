package com.xie.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xie.domain.Product;
import com.xie.service.IProductService;

@Controller
@RequestMapping("/product")
public class productAction {
	@Autowired
	private IProductService service;
	@RequestMapping("/list")
	public String  list(String cmd,HttpServletRequest req, HttpServletResponse resp, HttpSession session) throws ServletException, IOException{
		List<Product> list = service.find();
		session.setAttribute("products", list);
		if (cmd.equals("1")) {
			return "views/product/list";
		}
		return "views/product/add";
	}
	@RequestMapping("/save")
	public String  save(String id,String productName,String brand,String supplier,
			String salePrice,String costPrice,String cutoff,String leftNum,String saleNum,HttpServletRequest req, HttpServletResponse resp, HttpSession session) throws ServletException, IOException{
		Product p = new Product();
		String getproductName = new String(productName.getBytes("ISO-8859-1"),"utf-8");
		String getbrand = new String(brand.getBytes("ISO-8859-1"),"utf-8");
		String getsupplier = new String(supplier.getBytes("ISO-8859-1"),"utf-8");
		Integer getLeftNum = Integer.parseInt(leftNum);
		Integer getSaleNum = Integer.parseInt(saleNum);
		p.setProductName(getproductName);
		p.setBrand(getbrand);
		p.setSupplier(getsupplier);
		p.setSalePrice(Double.valueOf(salePrice));
		p.setCostPrice(Double.valueOf(costPrice));
		p.setCutoff(Double.valueOf(cutoff));
		p.setLeftNum(getLeftNum);
		p.setSaleNum(getSaleNum);
		List<Product> list = service.find();
		int flag = 0;
		if (id.trim() != "") {
			Integer getid =Integer.parseInt(id.trim());
		for (Product product : list) {
			if (product.getPid().equals(getid)) {
				p.setPid(getid);
				service.update(p);
				flag = 1;
				break;
			}
		}
		}
		if (flag == 0) {
			service.save(p);
		}
		list = service.find();
		session.setAttribute("products", list);
		return "views/product/list";
	}
	@RequestMapping("/delete")
	public String  delete(String id, HttpSession session) throws ServletException, IOException{
		Integer getid =Integer.parseInt(id);
		List<Product> list = service.find();
		for (Product product : list) {
			if (product.getPid().equals(getid)) {
				service.delete(getid);
				break;
			}
		}
		list = service.find();
		session.setAttribute("products", list);
		return "views/product/list";
	}
	@RequestMapping("/edit")
	public String  edit(String id, HttpSession session,HttpServletRequest req) throws ServletException, IOException{
		Integer getid =Integer.parseInt(id);
		List<Product> list = service.find();
		for (Product product : list) {
			if (product.getPid().equals(getid)) {
				req.setAttribute("product", product);
				break;
			}
		}
		return "views/product/edit";
	}
}
