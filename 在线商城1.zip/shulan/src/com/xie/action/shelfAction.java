package com.xie.action;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xie.domain.Product;
import com.xie.domain.Shelf;
import com.xie.service.IProductService;
import com.xie.service.IShelfService;

@Controller
@RequestMapping("/shelf")
public class shelfAction {
	@Autowired
	private IShelfService service;
	@Autowired
	private IProductService pservice;
	@RequestMapping("/list")
	public String  list(HttpServletRequest req, HttpServletResponse resp, HttpSession session) throws ServletException, IOException{
		List<Shelf> list = service.find();
		session.setAttribute("shelfs", list);
			return "views/shelf/list";
	}
	@RequestMapping("/save")
	public String  save(String id,String place,String type,HttpServletRequest req, HttpServletResponse resp, HttpSession session) throws ServletException, IOException{
		Shelf p = new Shelf();
		String getPlace = new String(place.getBytes("ISO-8859-1"),"utf-8");
		String getType = new String(type.getBytes("ISO-8859-1"),"utf-8");
		p.setPlace(getPlace);
		p.setType(getType);
		Set products = (Set) pservice.find();
		p.setProducts(products);
		List<Shelf> list = service.find();
		int flag = 0;
		if (id.trim() != "") {
			Integer getid =Integer.parseInt(id.trim());
		for (Shelf shelf : list) {
			if (shelf.getSid().equals(getid)) {
				p.setSid(getid);
				service.update(p);
				flag = 1;
				break;
			}
		}
		}
		if (flag == 0) {
			service.save(p);
		}
		list = service.find();
		session.setAttribute("shelfs", list);
		System.out.println(p.toString());
		return "views/shelf/list";
	}
	@RequestMapping("/delete")
	public String  delete(String id, HttpSession session) throws ServletException, IOException{
		Integer getid =Integer.parseInt(id);
		List<Shelf> list = service.find();
		for (Shelf shelf : list) {
			if (shelf.getSid().equals(getid)) {
				service.delete(getid);
				break;
			}
		}
		list = service.find();
		session.setAttribute("shelfs", list);
		return "views/shelf/list";
	}
	@RequestMapping("/edit")
	public String  edit(String id, HttpSession session,HttpServletRequest req) throws ServletException, IOException{
		Integer getid =Integer.parseInt(id);
		List<Shelf> list = service.find();
		for (Shelf shelf : list) {
			if (shelf.getSid().equals(getid)) {
				req.setAttribute("shelf", shelf);
				break;
			}
		}
		return "views/shelf/edit";
	}
}
