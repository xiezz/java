package com.xie.domain;

import java.sql.Timestamp;

/**
 * Loss entity. @author MyEclipse Persistence Tools
 */

public class Loss implements java.io.Serializable {

	// Fields

	private Integer lid;
	private Shelf shelf;
	private Product product;
	private Timestamp losstime;

	// Constructors

	/** default constructor */
	public Loss() {
	}

	/** full constructor */
	public Loss(Shelf shelf, Product product, Timestamp losstime) {
		this.shelf = shelf;
		this.product = product;
		this.losstime = losstime;
	}

	// Property accessors

	public Integer getLid() {
		return this.lid;
	}

	public void setLid(Integer lid) {
		this.lid = lid;
	}

	public Shelf getShelf() {
		return this.shelf;
	}

	public void setShelf(Shelf shelf) {
		this.shelf = shelf;
	}

	public Product getProduct() {
		return this.product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Timestamp getLosstime() {
		return this.losstime;
	}

	public void setLosstime(Timestamp losstime) {
		this.losstime = losstime;
	}

}