package com.xie.action;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xie.domain.Roles;
import com.xie.domain.User;
import com.xie.service.IRolesService;
import com.xie.service.IUserService;

@Controller
@RequestMapping("/user")
public class userAction {
	@Autowired
	private IUserService service;
	@Autowired
	private IRolesService rservice;
	@RequestMapping("/list")
	public String  list(HttpServletRequest req, HttpServletResponse resp, HttpSession session) throws ServletException, IOException{
		List<User> list = service.find();
		List<Roles> rlist = rservice.find();
		session.setAttribute("users", list);
		session.setAttribute("dirs", rlist);
			return "views/user/list";
	}
	@RequestMapping("/save")
	public String  save(String id,String userName,String password,HttpServletRequest req, String rid,HttpServletResponse resp, HttpSession session) throws ServletException, IOException{
		User p = new User();
		String getUserName = new String(userName.getBytes("ISO-8859-1"),"utf-8");
		String getPassword = new String(password.getBytes("ISO-8859-1"),"utf-8");
		Integer getRid = Integer.valueOf(rid);
		Date date =  new Date();
		List<User> list = service.find();
		p.setPassword(getPassword);
		p.setUsername(getUserName);
		Roles r = rservice.find(getRid);
		p.setRoles(r);
		p.setHiredate(date);
		int flag = 0;
		if (id.trim() != "") {
			Integer getid =Integer.parseInt(id.trim());
		for (User User : list) {
			if (User.getUid().equals(getid)) {
				p.setUid(getid);
				service.update(p);
				flag = 1;
				break;
			}
		}
		}
		if (flag == 0) {
			service.save(p);
		}
		list = service.find();
		session.setAttribute("users", list);
		return "views/user/list";
	}
	@RequestMapping("/delete")
	public String  delete(String id, HttpSession session) throws ServletException, IOException{
		Integer getid =Integer.parseInt(id);
		List<User> list = service.find();
		for (User user : list) {
			if (user.getUid().equals(getid)) {
				service.delete(getid);
				break;
			}
		}
		list = service.find();
		session.setAttribute("users", list);
		return "views/user/list";
	}
	@RequestMapping("/edit")
	public String  edit(String id, HttpSession session,HttpServletRequest req) throws ServletException, IOException{
		Integer getid =Integer.parseInt(id);
		List<User> list = service.find();
		for (User User : list) {
			if (User.getUid().equals(getid)) {
				req.setAttribute("user", User);
				break;
			}
		}
		return "views/user/edit";
	}
}
