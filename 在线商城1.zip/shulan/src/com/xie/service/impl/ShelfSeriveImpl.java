package com.xie.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xie.dao.IShelfDao;
import com.xie.domain.Shelf;
import com.xie.service.IShelfService;

@Service
@Transactional
public class ShelfSeriveImpl implements IShelfService{
	
	@Autowired
	private IShelfDao dao;
	public void save(Shelf r) {
		dao.save(r);
	}

	public void delete(Integer rid) {
		dao.delete(rid);
	}

	public void update(Shelf r) {
		dao.update(r);
	}

	public List<Shelf> find() {
		return dao.find();
	}

	public Shelf find(Integer rid) {
		return dao.find(rid);
	}

}
