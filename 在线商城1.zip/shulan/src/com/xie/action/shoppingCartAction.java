package com.xie.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xie.domain.CartItem;
import com.xie.domain.Product;
import com.xie.service.IProductService;


@Controller
@RequestMapping("/shoppingCart")
public class shoppingCartAction {
	@Autowired
	private IProductService service;
	@RequestMapping("/save")
	protected String save(String id, String num, HttpSession session)
			throws ServletException, IOException {
		Integer iid = Integer.parseInt(id);
		Product p = service.find(iid);
		String name = p.getProductName();
		Integer number = Integer.parseInt(num);
		Integer Num = p.getLeftNum();
		Double price  = p.getSalePrice();
		if (Integer.valueOf(number) >Integer.valueOf(Num)) {
			number = Num;
		}
		CartItem c = new CartItem(iid ,name, price, number,Num);
		ArrayList<CartItem> list=(ArrayList<CartItem>) session.getAttribute("SHOPPINGCART_IN_SESSION");
		if (list == null) {
			list = new ArrayList<CartItem>();
			session.setAttribute("SHOPPINGCART_IN_SESSION", list);
		}
		int flag = 0;
		for (CartItem item: list) {
				if (item.getId().equals(c.getId())) {
					item.setNum(item.getNum() +	c.getNum());
					flag = 1;
					break;
				}
		}
		if (flag == 0) {
			list.add(c);
		}
		double totalprice = 0;
		for (CartItem item: list) {
			totalprice += item.getPrice()*item.getNum();
			}
		session.setAttribute("totalPrice", totalprice);
		return "shoppingcart/cart_list";
	}
	@RequestMapping("/delete")
	protected String delete(HttpServletRequest req,HttpSession session)
			throws ServletException, IOException {
		Integer id =Integer.parseInt( req.getParameter("id"));
		ArrayList<CartItem> list=(ArrayList<CartItem>) session.getAttribute("SHOPPINGCART_IN_SESSION");
		Iterator<CartItem> it = list.iterator();
		while (it.hasNext()) {
			CartItem item = it.next();
			if (item.getId().equals(id)) {
				it.remove();
				break;
			}
		}
				return "shoppingcart/cart_list";
	}
	@RequestMapping("/agree")
	protected String agree(HttpServletRequest req,HttpSession session,HttpServletResponse resq)
			throws ServletException, IOException {
			ArrayList<CartItem> car=(ArrayList<CartItem>) session.getAttribute("SHOPPINGCART_IN_SESSION");
			List<Product> list = service.find();
			for (CartItem c : car) {
				for (Product p : list) {
				if (p.getPid().equals(c.getId())) {
					p.setLeftNum(p.getLeftNum()+c.getNum());
					p.setSaleNum(p.getSaleNum()-c.getNum());
					service.update(p);
					break;
					}
				}
			}
			session.invalidate();
			return "shoppingcart/agree";
}
}
